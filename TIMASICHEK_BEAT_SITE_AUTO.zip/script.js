/*
  ДОБАВЛЕНИЕ БИТОВ:
  На GitHub Pages сайт сам получает список MP3 из папки beats.
  Просто загрузи новый .mp3 в beats — он появится после обновления сайта.

  ВАЖНО: перед публикацией впиши данные репозитория ниже.
*/
const GITHUB_USER = "YOUR_GITHUB_USERNAME";
const GITHUB_REPO = "TIMASICHEK_BEAT_SITE";
const GITHUB_BRANCH = "main";

const grid = document.querySelector("#beatGrid");
let current=null,currentBeat=null;

async function getBeats(){
  // Для локального index.html используем manifest.json.
  // На GitHub Pages автоматически читаем папку beats через GitHub API.
  try{
    if(GITHUB_USER !== "YOUR_GITHUB_USERNAME"){
      const api=`https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}/contents/beats?ref=${GITHUB_BRANCH}`;
      const r=await fetch(api); if(!r.ok) throw new Error("GitHub");
      const files=await r.json();
      return files.filter(x=>x.type==="file" && /\.mp3$/i.test(x.name))
        .map(x=>({file:x.name,name:x.name.replace(/\.mp3$/i,"").replace(/[-_]/g," ")}));
    }
  }catch(e){}
  const r=await fetch("beats.json"); return await r.json();
}

function card(b,i){
 const file="beats/"+encodeURIComponent(b.file).replace(/%2F/g,"/");
 const safe=(b.name||b.file).replace(/\.mp3$/i,"");
 const bpm=b.bpm?`${b.bpm} BPM`:"BEAT";
 const key=b.key||"KEY N/A";
 return `<article class="beat" data-file="${file}" data-name="${safe}">
 <div class="art art${(i%6)+1}">${String(i+1).padStart(2,"0")}</div>
 <div class="info"><h2>${safe}</h2><p>${b.genre||"Rage"} · ${bpm} · ${key}</p>
 <div class="controls"><button class="play">▶</button><div class="wave"></div><span class="duration">--:--</span></div></div>
 <a class="dl" href="${file}" download>DOWNLOAD</a></article>`;
}

async function init(){
 try{
  const beats=await getBeats();
  grid.innerHTML=beats.length?beats.map(card).join(""):`<div class="loading">NO BEATS YET</div>`;
  bind();
 }catch(e){grid.innerHTML=`<div class="loading">ADD MP3 FILES TO THE BEATS FOLDER</div>`}
}
function bind(){
 document.querySelectorAll(".beat").forEach(beat=>{
  const audio=new Audio(beat.dataset.file),btn=beat.querySelector(".play"),dur=beat.querySelector(".duration");
  audio.addEventListener("loadedmetadata",()=>dur.textContent=fmt(audio.duration));
  audio.addEventListener("timeupdate",()=>{
   dur.textContent=fmt(audio.currentTime);
   if(current===audio){document.querySelector("#nowTime").textContent=`${fmt(audio.currentTime)} / ${fmt(audio.duration)}`;document.querySelector("#progress").style.width=(audio.currentTime/audio.duration*100)+"%";}
  });
  audio.addEventListener("ended",()=>{btn.textContent="▶";});
  btn.onclick=async()=>{
   if(current&&current!==audio){current.pause();currentBeat.querySelector(".play").textContent="▶";}
   if(audio.paused){try{await audio.play()}catch(e){alert("Этот MP3 ещё не загружен.")}btn.textContent="Ⅱ";current=audio;currentBeat=beat;document.querySelector("#nowName").textContent="/ "+beat.dataset.name}
   else{audio.pause();btn.textContent="▶";}
  };
 });
}
function fmt(x){if(!isFinite(x))return"0:00";return Math.floor(x/60)+":"+String(Math.floor(x%60)).padStart(2,"0")}
init();